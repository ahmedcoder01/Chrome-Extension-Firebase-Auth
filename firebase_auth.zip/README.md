# <img src="public/icons/icon_48.png" width="45" align="left"> Firebase_auth

My Chrome Extension

## Features

- Feature 1
- Feature 2

## Install

[**Chrome** extension]() <!-- TODO: Add chrome extension link inside parenthesis -->

## Contribution

Suggestions and pull requests are welcomed!.

---

This project was bootstrapped with [Chrome Extension CLI](https://github.com/dutiyesh/chrome-extension-cli)

